#ifndef YUATTACK_AOTREE_H
#define YUATTACK_AOTREE_H


// A binary tree representing boolean formulas
class AOTree {
public:
    virtual ~AOTree() = default;
};

// AND node
class AOAnd final: public AOTree {
public:
    AOAnd(AOTree *n1, AOTree *n2);
    ~AOAnd() override;
    [[nodiscard]] AOTree *getN1();
    [[nodiscard]] AOTree *getN2();
private:
    AOTree *n1;
    AOTree *n2;
};

// OR node
class AOOr final: public AOTree {
public:
    AOOr(AOTree *n1, AOTree *n2);
    ~AOOr() override;
    [[nodiscard]] AOTree *getN1();
    [[nodiscard]] AOTree *getN2();
private:
    AOTree *n1;
    AOTree *n2;
};

// Attribute node
class AOAttribute final: public AOTree {
public:
    explicit AOAttribute(int attr);
    ~AOAttribute() override;
    [[nodiscard]] int getAttribute() const;
private:
    int attribute;
};

#endif //YUATTACK_AOTREE_H

