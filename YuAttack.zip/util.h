#ifndef YUATTACK_UTIL_H
#define YUATTACK_UTIL_H

#include <vector>
#include <unordered_set>
#include <typeinfo>
#include <pbc.h>

void scalar_product_ui(element_t result, pairing_t pairing, const std::vector<element_t *>& v1,
                       const std::vector<int>& v2);
void scalar_product(element_t result, pairing_t pairing, const std::vector<element_t *>& v1,
                    const std::vector<element_t *>& v2);

template <typename T>
std::vector<T> uset_vector_intersection(std::unordered_set<T> uset, std::vector<T> vec) {
    std::vector<T> res;
    for (auto t : vec)
        if (uset.contains(t)) {
            res.push_back(t);
            uset.erase(t);
        }
    return res;
}

template <typename T>
std::vector<T> vector_intersection(std::vector<T> v1, std::vector<T> v2) {
    std::unordered_set<T> uset(v1.begin(), v1.end());
    return uset_vector_intersection(uset, v2);
}

template<typename T, typename K>
inline bool isType(const K &k) {
    return typeid(T).hash_code() == typeid(k).hash_code();
}

#endif //YUATTACK_UTIL_H
