#include "AOTree.h"

AOAnd::AOAnd(AOTree *n1, AOTree *n2) {
    this->n1 = n1;
    this->n2 = n2;
}

AOAnd::~AOAnd() {
    delete n1;
    delete n2;
}

AOTree *AOAnd::getN1() {
    return n1;
}

AOTree *AOAnd::getN2() {
    return n2;
}

AOOr::AOOr(AOTree *n1, AOTree *n2) {
    this->n1 = n1;
    this->n2 = n2;
}

AOOr::~AOOr() {
    delete n1;
    delete n2;
}

AOTree *AOOr::getN1() {
    return n1;
}

AOTree *AOOr::getN2() {
    return n2;
}

AOAttribute::AOAttribute(int attribute) {
    this->attribute = attribute;
}

int AOAttribute::getAttribute() const {
    return attribute;
}

AOAttribute::~AOAttribute() = default;
