#include "ywnl.h"
#include <vector>
#include <iostream>
#include <map>
#include <unordered_set>
#include "AOTree.h"
#include "util.h"
#include "secret_sharing.h"
#include "LSSS.h"

// Yu et al. - Decentralized, Revocable and Verifiable Attribute‑Based Encryption in Hybrid Cloud System - 2019

struct ywnl_global_public_parameters {
    element_t *g{};
    element_t *egg{};
    element_t *g_c{};
    std::map<int, int> attribute_to_authority_map;
};

struct ywnl_master_secret_key {
    std::vector<element_t *> ns;
};

struct ywnl_apk_attribute_data {
    std::unordered_set<int> users;
    element_t *pk1{};
    element_t *pk2{};
    std::map<int, element_t *> ws;
};

struct ywnl_authority_public_key {
    int authority_id{};
    element_t *egg_alpha{};
    element_t *g_c_delta{};
    std::map<int, ywnl_apk_attribute_data> attribute_data;
};

struct ywnl_ask_attribute_data {
    std::map<int, element_t *> vs;
    std::map<int, element_t *> ts;
};

struct ywnl_authority_secret_key {
    element_t *g_n{};
    element_t *alpha{};
    element_t *beta{};
    element_t *gamma{};
    element_t *delta{};
    std::map<int, ywnl_ask_attribute_data> attribute_data;
};

struct ywnl_user_secret_key {
    int user_id{};
    std::vector<int> S;
    std::map<int, std::pair<element_t *, element_t *>> authority_keys;
    std::map<int, std::tuple<element_t *, element_t *, element_t *, element_t *>> attribute_keys;
};

struct ywnl_ciphertext {
    AOTree *policy{};
    element_t *C{};
    element_t *Cprime{};
    std::map<int, std::tuple<element_t *, element_t *, element_t *>> attribute_values;
};

struct ywnl_auditing_key {
    std::map<int, element_t *> AKs;
};

// Central Authority Setup
void ywnl_ca_setup(ywnl_global_public_parameters& gpp, ywnl_master_secret_key& msk,
                   std::vector<ywnl_authority_secret_key>& asks, pairing_t pairing,
                   const std::map<int, int>& attribute_to_authority_map, int m) {
    // Global Public Parameters
    gpp.attribute_to_authority_map = attribute_to_authority_map;
    gpp.g = static_cast<element_t *>(malloc(sizeof(element_t)));
    element_init_G1(*gpp.g, pairing);
    element_random(*gpp.g);
    gpp.egg = static_cast<element_t *>(malloc(sizeof(element_t)));
    element_init_GT(*gpp.egg, pairing);
    element_pairing(*gpp.egg, *gpp.g, *gpp.g);

    element_pp_t g_pp;
    element_pp_init(g_pp, *gpp.g);
    element_t temp;
    element_init_Zr(temp, pairing);
    element_random(temp);
    gpp.g_c = static_cast<element_t *>(malloc(sizeof(element_t)));
    element_init_G1(*gpp.g_c, pairing);
    element_pp_pow_zn(*gpp.g_c, temp, g_pp);

    // Master Secret Key
    element_set0(temp);
    msk.ns.reserve(m);
    for (int i = 0; i < m - 1; ++i) {
        auto n_i = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_Zr(*n_i, pairing);
        element_random(*n_i);
        element_add(temp, temp, *n_i);
        msk.ns.push_back(n_i);
    }
    auto nm = static_cast<element_t *>(malloc(sizeof(element_t)));
    element_init_Zr(*nm, pairing);
    element_neg(*nm, temp);
    msk.ns.push_back(nm);
    element_clear(temp);
    for (int i = 0; i < m; ++i) {
        auto g_n = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_G1(*g_n, pairing);
        element_pp_pow_zn(*g_n, *msk.ns[i], g_pp);
        asks[i].g_n = g_n;
    }
    element_pp_clear(g_pp);
}

// Attribute Authority Setup
void ywnl_aa_setup(ywnl_authority_public_key& apk, ywnl_authority_secret_key& ask, pairing_t pairing,
                   int authority_id, const std::vector<int>& S, ywnl_global_public_parameters& gpp) {
    // Default users
    int num_users = 2;
    // Authority Secret Key
    ask.alpha = static_cast<element_t *>(malloc(sizeof(element_t)));
    element_init_Zr(*ask.alpha, pairing);
    element_random(*ask.alpha);
    ask.beta = static_cast<element_t *>(malloc(sizeof(element_t)));
    element_init_Zr(*ask.beta, pairing);
    element_random(*ask.beta);
    ask.gamma = static_cast<element_t *>(malloc(sizeof(element_t)));
    element_init_Zr(*ask.gamma, pairing);
    element_random(*ask.gamma);
    ask.delta = static_cast<element_t *>(malloc(sizeof(element_t)));
    element_init_Zr(*ask.delta, pairing);
    element_random(*ask.delta);
    // Authority Public Key
    apk.authority_id = authority_id;
    apk.egg_alpha = static_cast<element_t *>(malloc(sizeof(element_t)));
    element_init_GT(*apk.egg_alpha, pairing);
    element_pow_zn(*apk.egg_alpha, *gpp.egg, *ask.alpha);
    apk.g_c_delta = static_cast<element_t *>(malloc(sizeof(element_t)));
    element_init_G1(*apk.g_c_delta, pairing);
    element_pow_zn(*apk.g_c_delta, *gpp.g_c, *ask.delta);
    // Authority Public Key attribute values
    element_pp_t g_pp;
    element_pp_init(g_pp, *gpp.g);
    element_t v_product, gamma_delta, beta_inv, temp;
    element_init_Zr(v_product, pairing);
    element_init_Zr(gamma_delta, pairing);
    element_init_Zr(beta_inv, pairing);
    element_init_Zr(temp, pairing);
    element_mul(gamma_delta, *ask.gamma, *ask.delta);
    element_invert(beta_inv, *ask.beta);
    std::vector<element_t *> vs(num_users);
    for (auto attr : S) {
        ywnl_apk_attribute_data& apk_ad = apk.attribute_data[attr];
        for (int i = 0; i < num_users; ++i) {
            apk_ad.users.insert(i);
        }
        for (int i = 0; i < num_users; ++i) {
            vs[i] = static_cast<element_t *>(malloc(sizeof(element_t)));
            element_init_Zr(*vs[i], pairing);
            element_random(*vs[i]);
        }
        element_set1(v_product);
        for (auto v : vs) {
            element_mul(v_product, v_product, *v);
        }
        apk_ad.pk1 = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_G1(*apk_ad.pk1, pairing);
        element_mul(temp, v_product, beta_inv);
        element_pp_pow_zn(*apk_ad.pk1, temp, g_pp);
        apk_ad.pk2 = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_G1(*apk_ad.pk2, pairing);
        element_from_hash(*apk_ad.pk2, &attr, sizeof(int));
        element_mul(temp, gamma_delta, v_product);
        element_pow_zn(*apk_ad.pk2, *apk_ad.pk2, temp);
        element_invert(v_product, v_product);
        ywnl_ask_attribute_data& ask_ad = ask.attribute_data[attr];
        for (int i = 0; i < num_users; ++i) {
            auto t = static_cast<element_t *>(malloc(sizeof(element_t)));
            element_init_Zr(*t, pairing);
            element_random(*t);
            auto w = static_cast<element_t *>(malloc(sizeof(element_t)));
            element_init_Zr(*w, pairing);
            element_mul(*w, *t, v_product);
            element_mul(*w, *w, *vs[i]);
            element_add(*w, *w, *vs[i]);
            apk_ad.ws[i] = w;
            ask_ad.vs[i] = vs[i];
            ask_ad.ts[i] = t;
        }
    }
    element_pp_clear(g_pp);
    element_clear(v_product);
    element_clear(gamma_delta);
    element_clear(beta_inv);
    element_clear(temp);
}

void ywnl_key_generation(ywnl_user_secret_key& usk, pairing_t pairing, ywnl_authority_public_key& apk,
                         ywnl_authority_secret_key& ask, const std::vector<int>& S, int user_id,
                         ywnl_global_public_parameters& gpp) {
    usk.user_id = user_id;
    usk.S.insert(usk.S.end(), S.begin(), S.end());
    element_t uid, temp, temp2, temp_g1;
    element_init_Zr(uid, pairing);
    element_init_Zr(temp, pairing);
    element_init_Zr(temp2, pairing);
    element_init_G1(temp_g1, pairing);
    element_pp_t g_pp;
    element_pp_init(g_pp, *gpp.g);
    element_set_si(uid, user_id);
    auto k = static_cast<element_t *>(malloc(sizeof(element_t)));
    element_init_G1(*k, pairing);
    element_pp_pow_zn(*k, *ask.alpha, g_pp);
    element_mul(temp_g1, *gpp.g_c, *ask.g_n);
    element_pow_zn(temp_g1, temp_g1, uid);
    element_mul(*k, *k, temp_g1);
    auto kprime = static_cast<element_t *>(malloc(sizeof(element_t)));
    element_init_G1(*kprime, pairing);
    element_div(temp, uid, *ask.delta);
    element_pp_pow_zn(*kprime, temp, g_pp);
    usk.authority_keys[apk.authority_id] = {k, kprime};
    element_pp_clear(g_pp);
    for (auto attr : S) {
        auto v = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_Zr(*v, pairing);
        element_random(*v);
        auto t = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_Zr(*t, pairing);
        element_random(*t);
        ywnl_ask_attribute_data& ask_ad = ask.attribute_data[attr];
        ask_ad.vs[user_id] = v;
        ask_ad.ts[user_id] = t;
        element_from_hash(temp_g1, &attr, sizeof(int));
        element_pp_t hattr_pp;
        element_pp_init(hattr_pp, temp_g1);
        auto k4 = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_G1(*k4, pairing);
        element_mul(temp, *ask.beta, *ask.gamma);
        element_mul(temp2, temp, *v);
        element_pp_pow_zn(*k4, temp2, hattr_pp);
        auto k1 = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_G1(*k1, pairing);
        element_mul(temp2, uid, *ask.beta);
        element_add(temp, temp, temp2);
        element_pp_pow_zn(*k1, temp, hattr_pp);
        auto k2 = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_G1(*k2, pairing);
        element_sub(temp, *ask.gamma, *v);
        element_mul(temp, temp, temp2);
        element_pp_pow_zn(*k2, temp, hattr_pp);
        auto k3 = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_G1(*k3, pairing);
        element_neg(temp, *t);
        element_mul(temp, temp, *v);
        element_add(temp2, uid, *ask.gamma);
        element_mul(temp, temp, temp2);
        element_pp_pow_zn(*k3, temp, hattr_pp);
        usk.attribute_keys[attr] = std::make_tuple(k1, k2, k3, k4);
        element_pp_clear(hattr_pp);
    }
    element_clear(uid);
    element_clear(temp);
    element_clear(temp2);
    element_clear(temp_g1);
}

void ywnl_encryption(ywnl_ciphertext &ct, ywnl_auditing_key& ak, pairing_t pairing, element_t message, AOTree *policy,
                     std::vector<ywnl_authority_public_key>& apks, ywnl_global_public_parameters& gpp) {
    ct.policy = policy;
    LSSS *lsss = LSSS::from_AOTree(policy);
    size_t rows = lsss->get_rows();
    size_t cols = lsss->get_cols();
    if (cols < 1) {
        pbc_die("Empty LSSS");
    }
    std::unordered_set<int> authorities_set;
    for (int i = 0; i < rows; ++i) {
        authorities_set.insert(gpp.attribute_to_authority_map[lsss->get_attr_from_row(i)]);
    }
    std::vector<element_t *> v(cols);
    for (int i = 0; i < cols; ++i) {
        v[i] = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_Zr(*v[i], pairing);
        element_random(*v[i]);
    }
    element_pp_t g_pp, gc_pp;
    element_pp_init(g_pp, *gpp.g);
    element_pp_init(gc_pp, *gpp.g_c);
    ct.C = static_cast<element_t *>(malloc(sizeof(element_t)));
    element_init_GT(*ct.C, pairing);
    element_set1(*ct.C);
    for (auto auth : authorities_set) {
        ywnl_authority_public_key& apk = apks[auth];
        element_mul(*ct.C, *ct.C, *apk.egg_alpha);
    }
    element_pow_zn(*ct.C, *ct.C, *v[0]);
    element_mul(*ct.C, *ct.C, message);
    ct.Cprime = static_cast<element_t *>(malloc(sizeof(element_t)));
    element_init_G1(*ct.Cprime, pairing);
    element_pp_pow_zn(*ct.Cprime, *v[0], g_pp);
    element_t r, lambda;
    element_init_Zr(r, pairing);
    element_init_Zr(lambda, pairing);
    for (int i = 0; i < rows; ++i) {
        int attr = lsss->get_attr_from_row(i);
        ywnl_authority_public_key& apk = apks[gpp.attribute_to_authority_map[attr]];
        ywnl_apk_attribute_data& apk_ad = apk.attribute_data[attr];
        element_random(r);
        auto Cprimei = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_G1(*Cprimei, pairing);
        element_pow_zn(*Cprimei, *apk_ad.pk1, r);
        auto Di = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_G1(*Di, pairing);
        element_pp_pow_zn(*Di, r, g_pp);
        auto AKi = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_G1(*AKi, pairing);
        scalar_product_ui(lambda, pairing, v, lsss->get_row(i));
        element_pow_zn(*AKi, *apk.g_c_delta, lambda);
        auto Ci = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_G1(*Ci, pairing);
        element_neg(r, r);
        element_pow_zn(*Ci, *apk_ad.pk2, r);
        element_mul(*Ci, *Ci, *AKi);
        ct.attribute_values[attr] = std::make_tuple(Ci, Cprimei, Di);
        ak.AKs[attr] = AKi;
    }
    delete lsss;
    for (auto val : v) {
        element_clear(*val);
        free(val);
    }
    element_clear(r);
    element_clear(lambda);
    element_pp_clear(g_pp);
    element_pp_clear(gc_pp);
}

void ywnl_decryption(element_t message, pairing_t pairing, ywnl_ciphertext& ct, ywnl_user_secret_key& usk,
                     std::vector<ywnl_authority_public_key>& apks, ywnl_global_public_parameters& gpp) {
    std::optional<LSSS *> lsss_opt = LSSS::from_AOTree_decrypt(ct.policy, usk.S);
    if (!lsss_opt.has_value()) {
        pbc_die("Attributes for Decryption do not match");
    }
    LSSS *lsss = lsss_opt.value();
    std::map<int, element_t *> omegas = solve_lsss(pairing, lsss);
    int rows = lsss->get_rows();
    std::unordered_set<int> authorities_set;
    for (int i = 0; i < rows; ++i) {
        authorities_set.insert(gpp.attribute_to_authority_map[lsss->get_attr_from_row(i)]);
    }
    size_t num_auths = authorities_set.size();
    element_t ls[num_auths];
    element_t rs[num_auths];
    for (auto l : ls) {
        element_init_G1(l, pairing);
    }
    for (auto r : rs) {
        element_init_G1(r, pairing);
    }
    int counter = 0;
    for (auto auth : authorities_set) {
        element_set(ls[counter], *ct.Cprime);
        element_set(rs[counter], *usk.authority_keys[auth].first);
        ++counter;
    }
    element_prod_pairing(message, ls, rs, counter);
    element_invert(message, message);
    for (auto l : ls) {
        element_clear(l);
    }
    for (auto r : rs) {
        element_clear(r);
    }
    element_t m, temp, temp_gt, temp2_gt;
    element_init_Zr(m, pairing);
    element_init_Zr(temp, pairing);
    element_init_GT(temp_gt, pairing);
    element_init_GT(temp2_gt, pairing);
    element_t ls2[4];
    element_t rs2[4];
    for (auto l : ls2) {
        element_init_G1(l, pairing);
    }
    for (auto r : rs2) {
        element_init_G1(r, pairing);
    }
    element_set_si(m, apks.size());

    for (int i = 0; i < rows; ++i) {
        int attr = lsss->get_attr_from_row(i);
        int auth = gpp.attribute_to_authority_map[attr];
        std::tuple<element_t *, element_t *, element_t *>& ct_attr_tuple = ct.attribute_values[attr];
        std::tuple<element_t *, element_t *, element_t *, element_t *>& usk_attr_tuple = usk.attribute_keys[attr];
        element_set(ls2[0], *get<0>(ct_attr_tuple));
        element_set(rs2[0], *usk.authority_keys[auth].second);
        element_set(ls2[1], *get<1>(ct_attr_tuple));
        element_pow_zn(rs2[1], *get<0>(usk_attr_tuple), *apks[auth].attribute_data[attr].ws[usk.user_id]);
        element_set(ls2[2], *get<1>(ct_attr_tuple));
        element_set(rs2[2], *get<1>(usk_attr_tuple));
        element_set(ls2[3], *get<2>(ct_attr_tuple));
        element_set(rs2[3], *get<2>(usk_attr_tuple));
        element_prod_pairing(temp_gt, ls2, rs2, 4);
        element_pairing(temp2_gt, *get<1>(ct_attr_tuple), *get<3>(usk_attr_tuple));
        element_div(temp_gt, temp_gt, temp2_gt);
        element_mul(temp, *omegas[attr], m);
        element_pow_zn(temp_gt, temp_gt, temp);
        element_mul(message, message, temp_gt);
    }
    delete lsss;
    for (auto pair : omegas) {
        element_clear(*pair.second);
        free(pair.second);
    }
    for (auto l : ls2) {
        element_clear(l);
    }
    for (auto r : rs2) {
        element_clear(r);
    }
    element_clear(m);
    element_clear(temp);
    element_clear(temp_gt);
    element_clear(temp2_gt);

    element_mul(message, message, *ct.C);
}

void ywnl_decryption_attack(element_t message, pairing_t pairing, ywnl_ciphertext& ct, ywnl_user_secret_key& usk,
                     std::vector<ywnl_authority_public_key>& apks, ywnl_global_public_parameters& gpp) {
    LSSS *lsss = LSSS::from_AOTree(ct.policy);
    std::map<int, element_t *> omegas = solve_lsss(pairing, lsss);
    int rows = lsss->get_rows();
    std::unordered_set<int> authorities_set;
    for (int i = 0; i < rows; ++i) {
        authorities_set.insert(gpp.attribute_to_authority_map[lsss->get_attr_from_row(i)]);
    }
    delete lsss;
    size_t num_auths = authorities_set.size();
    element_t ls[num_auths];
    element_t rs[num_auths];
    for (auto l : ls) {
        element_init_G1(l, pairing);
    }
    for (auto r : rs) {
        element_init_G1(r, pairing);
    }
    int counter = 0;
    for (auto auth : authorities_set) {
        element_set(ls[counter], *ct.Cprime);
        element_set(rs[counter], *usk.authority_keys[auth].first);
        ++counter;
    }
    element_prod_pairing(message, ls, rs, counter);
    element_invert(message, message);
    for (auto l : ls) {
        element_clear(l);
    }
    for (auto r : rs) {
        element_clear(r);
    }
    element_t m, temp, temp_gt;
    element_init_Zr(m, pairing);
    element_init_Zr(temp, pairing);
    element_init_GT(temp_gt, pairing);

    element_set_si(m, apks.size());

    element_set1(temp_gt);
    element_pairing(temp_gt, *ct.Cprime, *gpp.g_c);
    element_set_si(temp, apks.size()*usk.user_id);
    element_pow_zn(temp_gt, temp_gt, temp);
    element_mul(message, message, temp_gt);

    for (auto pair : omegas) {
        element_clear(*pair.second);
        free(pair.second);
    }
    element_clear(m);
    element_clear(temp);
    element_clear(temp_gt);

    element_mul(message, message, *ct.C);
}

void ywnl_public_key_update(ywnl_authority_public_key& apk, ywnl_authority_secret_key& ask, pairing_t pairing, int user_id, const std::vector<int>& S) {
    element_t v_product;
    element_init_Zr(v_product, pairing);
    for (auto attr : S) {
        ywnl_ask_attribute_data& ask_ad = ask.attribute_data[attr];
        ywnl_apk_attribute_data& apk_ad = apk.attribute_data[attr];
        element_t *vu = ask_ad.vs[user_id];
        element_t *tu = ask_ad.ts[user_id];

        element_pow_zn(*apk_ad.pk1, *apk_ad.pk1, *vu);
        element_pow_zn(*apk_ad.pk2, *apk_ad.pk2, *vu);
        for (auto i : apk_ad.users) {
            element_t *wi = apk_ad.ws[i];
            element_t *vi = ask_ad.vs[i];
            element_sub(*wi, *wi, *vi);
            element_div(*wi, *wi, *vu);
            element_add(*wi, *wi, *vi);
        }

        auto wu = static_cast<element_t *>(malloc(sizeof(element_t)));
        element_init_Zr(*wu, pairing);
        element_set1(v_product);
        for (auto k : apk_ad.users) {
            element_mul(v_product, v_product, *ask_ad.vs[k]);
        }
        element_div(*wu, *tu, v_product);
        element_add(*wu, *wu, *vu);
        apk_ad.ws[user_id] = wu;
        apk_ad.users.insert(user_id);
    }
    element_clear(v_product);
}

void ywnl_run(pairing_t pairing) {
    // Setup
    ywnl_global_public_parameters gpp;
    ywnl_master_secret_key msk;
    int num_authorities = 2;
    std::vector<ywnl_authority_public_key> apks(num_authorities);
    std::vector<ywnl_authority_secret_key> asks(num_authorities);
    std::vector<std::vector<int>> auth_attrs{{1, 2}, {3}};
    std::map<int, int> attribute_to_authority_map;
    for (int i = 0; i < auth_attrs.size(); ++i) {
        for (auto attr : auth_attrs[i]) {
            attribute_to_authority_map[attr] = i;
        }
    }
    ywnl_user_secret_key recipient_usk;
    ywnl_user_secret_key attacker_usk;
    ywnl_ciphertext ct;
    ywnl_auditing_key ak;
    element_t sent_message, received_message;
    element_init_GT(sent_message, pairing);
    element_init_GT(received_message, pairing);

    // Parameters
    std::vector<std::vector<int>> recipient_attrs{{2}, {3}};
    std::vector<std::vector<int>> attacker_attrs{{}, {}};
    int recipient_uid = 2;
    int attacker_uid = 3;
    // Ciphertext Policy: 1 OR (2 AND 3)
    AOTree *publisher_policy = new AOOr(
            new AOAttribute(1),
            new AOAnd(
                    new AOAttribute(2),
                    new AOAttribute(3)
                    ));

    // Program
    // Randomly generate a message to be encrypted
    element_random(sent_message);
    // Setup Central Authority
    ywnl_ca_setup(gpp, msk, asks, pairing, attribute_to_authority_map, num_authorities);
    pbc_info("CA setup finished");
    // Setup Attribute Authorities
    for (int i = 0; i < num_authorities; ++i) {
        ywnl_aa_setup(apks[i], asks[i], pairing, i, auth_attrs[i], gpp);
    }
    pbc_info("AA setup finished");
    // Generate a user secret key for the regular recipient
    for (int i = 0; i < num_authorities; ++i) {
        ywnl_key_generation(recipient_usk, pairing, apks[i], asks[i], recipient_attrs[i], recipient_uid, gpp);
    }
    for (int i = 0; i < num_authorities; ++i) {
        ywnl_public_key_update(apks[i], asks[i], pairing, recipient_uid, recipient_attrs[i]);
    }
    pbc_info("Generated user secret key for the regular recipient");
    // Generate a user secret key for the attacker
    for (int i = 0; i < num_authorities; ++i) {
        ywnl_key_generation(attacker_usk, pairing, apks[i], asks[i], attacker_attrs[i], attacker_uid, gpp);
    }
    for (int i = 0; i < num_authorities; ++i) {
        ywnl_public_key_update(apks[i], asks[i], pairing, attacker_uid, attacker_attrs[i]);
    }
    pbc_info("Generated user secret key for the attacker");
    // Encrypt the message with its Ciphertext policy
    ywnl_encryption(ct, ak, pairing, sent_message, publisher_policy, apks, gpp);
	element_printf("Random message:\n%B\n", sent_message);
    pbc_info("Message encrypted");
    // The regular recipient decrypts the message
    ywnl_decryption(received_message, pairing, ct, recipient_usk, apks, gpp);
    pbc_info("Recipient: Message decrypted to");
	element_printf("%B\n", received_message);
    if (element_cmp(sent_message, received_message)) {
        pbc_error("Recipient: Received message does not match sent message");
    } else {
        pbc_info("Recipient: Received message matches sent message");
    }
    // The attacker decrypts the message
    ywnl_decryption_attack(received_message, pairing, ct, attacker_usk, apks, gpp);
    pbc_info("Attacker: Message decrypted to");
	element_printf("%B\n", received_message);
    if (element_cmp(sent_message, received_message)) {
        pbc_error("Attacker: Received message does not match sent message");
    } else {
        pbc_info("Attacker: Received message matches sent message");
    }
    pbc_info("Done");
    // Cleanup
    delete publisher_policy;
    element_clear(*gpp.g);
    free(gpp.g);
    element_clear(*gpp.egg);
    free(gpp.egg);
    element_clear(*gpp.g_c);
    free(gpp.g_c);
    for (auto n : msk.ns) {
        element_clear(*n);
        free(n);
    }
    for (int i = 0; i < num_authorities; ++i) {
        element_clear(*apks[i].egg_alpha);
        free(apks[i].egg_alpha);
        element_clear(*apks[i].g_c_delta);
        free(apks[i].g_c_delta);
        for (const auto& ad: apks[i].attribute_data) {
            element_clear(*ad.second.pk1);
            free(ad.second.pk1);
            element_clear(*ad.second.pk2);
            free(ad.second.pk2);
            for (auto pair : ad.second.ws) {
                element_clear(*pair.second);
                free(pair.second);
            }
        }
        element_clear(*asks[i].g_n);
        free(asks[i].g_n);
        element_clear(*asks[i].alpha);
        free(asks[i].alpha);
        element_clear(*asks[i].beta);
        free(asks[i].beta);
        element_clear(*asks[i].gamma);
        free(asks[i].gamma);
        element_clear(*asks[i].delta);
        free(asks[i].delta);
        for (const auto& ad: asks[i].attribute_data) {
            for (auto pair : ad.second.vs) {
                element_clear(*pair.second);
                free(pair.second);
            }
            for (auto pair : ad.second.ts) {
                element_clear(*pair.second);
                free(pair.second);
            }
        }
    }
    for (auto pair : recipient_usk.authority_keys) {
        auto t = pair.second;
        element_clear(*get<0>(t));
        free(get<0>(t));
        element_clear(*get<1>(t));
        free(get<1>(t));
    }
    for (auto pair : recipient_usk.attribute_keys) {
        auto t = pair.second;
        element_clear(*get<0>(t));
        free(get<0>(t));
        element_clear(*get<1>(t));
        free(get<1>(t));
        element_clear(*get<2>(t));
        free(get<2>(t));
        element_clear(*get<3>(t));
        free(get<3>(t));
    }
    for (auto pair : attacker_usk.authority_keys) {
        auto t = pair.second;
        element_clear(*get<0>(t));
        free(get<0>(t));
        element_clear(*get<1>(t));
        free(get<1>(t));
    }
    for (auto pair : attacker_usk.attribute_keys) {
        auto t = pair.second;
        element_clear(*get<0>(t));
        free(get<0>(t));
        element_clear(*get<1>(t));
        free(get<1>(t));
        element_clear(*get<2>(t));
        free(get<2>(t));
        element_clear(*get<3>(t));
        free(get<3>(t));
    }
    element_clear(*ct.C);
    free(ct.C);
    element_clear(*ct.Cprime);
    free(ct.Cprime);
    for (auto pair : ct.attribute_values) {
        auto t = pair.second;
        element_clear(*get<0>(t));
        free(get<0>(t));
        element_clear(*get<1>(t));
        free(get<1>(t));
        element_clear(*get<2>(t));
        free(get<2>(t));
    }
    for (auto pair : ak.AKs) {
        element_clear(*pair.second);
        free(pair.second);

    }
    element_clear(sent_message);
    element_clear(received_message);
}