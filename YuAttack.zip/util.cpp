#include "util.h"

void scalar_product_ui(element_t result, pairing_t pairing, const std::vector<element_t *>& v1,
                       const std::vector<int>& v2) {
    element_t temp;
    element_init_Zr(temp, pairing);
    element_set0(result);
    if (v1.size() != v2.size()) {
        pbc_die("Vector lengths do not match");
    }
    for (int i = 0; i < v1.size(); ++i) {
        element_set_si(temp, v2[i]);
        element_mul(temp, *v1[i], temp);
        element_add(result, result, temp);
    }
    element_clear(temp);
}

void scalar_product(element_t result, pairing_t pairing, const std::vector<element_t *>& v1,
                    const std::vector<element_t *>& v2) {
    element_t temp;
    element_init_Zr(temp, pairing);
    element_set0(result);
    if (v1.size() != v2.size()) {
        pbc_die("Vector lengths do not match");
    }
    for (int i = 0; i < v1.size(); ++i) {
        element_mul(temp, *v1[i], *v2[i]);
        element_add(result, result, temp);
    }
    element_clear(temp);
}
