#ifndef YUATTACK_SECRET_SHARING_H
#define YUATTACK_SECRET_SHARING_H

#include <pbc.h>
#include <map>
#include "LSSS.h"

std::map<int, element_t *> solve_lsss(pairing_t pairing, LSSS *lsss);

#endif //YUATTACK_SECRET_SHARING_H
