#include "ywnl.h"

int main() {
    pairing_t pairing;
    char param[1024];
    FILE *param_file = fopen("../param/a.param", "r");
    size_t count = fread(param, 1, 1024, param_file);
    if (!count) {
        pbc_die("Could not find parameter file");
    }
    pairing_init_set_buf(pairing, param, count);
    if (!pairing_is_symmetric(pairing)) {
        pbc_die("Pairing must be symmetric");
    }
    // Run the Simulation
    ywnl_run(pairing);

    pairing_clear(pairing);
    return 0;
}
