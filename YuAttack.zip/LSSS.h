#ifndef YUATTACK_LSSS_H
#define YUATTACK_LSSS_H

#include <vector>
#include <optional>
#include "AOTree.h"


// Contains the share-generating matrix for a Linear Secret Sharing Scheme (LSSS)
class LSSS {
public:
    [[nodiscard]] static LSSS *from_AOTree(AOTree *node);
    [[nodiscard]] static std::optional<LSSS *> from_AOTree_decrypt(AOTree *node, const std::vector<int>& attributes);
    LSSS(int rows, int cols, std::vector<std::vector<int>> matrix,
         std::vector<int> row_to_attr);
    [[nodiscard]] int get_rows() const;
    [[nodiscard]] int get_cols() const;
    [[nodiscard]] std::vector<int> get_row(int i);
    [[nodiscard]] int get_attr_from_row(int i);
    void print();
private:
    int rows;
    int cols;
    std::vector<std::vector<int>> matrix;
    std::vector<int> row_to_attr;
};

#endif //YUATTACK_LSSS_H
