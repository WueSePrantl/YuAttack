#ifndef YUATTACK_YWNL_H
#define YUATTACK_YWNL_H

#include <pbc.h>

void ywnl_run(pairing_t pairing);

#endif //YUATTACK_YWNL_H
