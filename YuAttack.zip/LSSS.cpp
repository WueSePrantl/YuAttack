#include "LSSS.h"
#include <queue>
#include <iostream>
#include "util.h"

// Lewko-Waters Algorithm: https://eprint.iacr.org/2010/351.pdf Appendix G
LSSS *LSSS::from_AOTree(AOTree *node) {
    int counter = 1;
    std::queue<std::pair<AOTree *, std::vector<int>>> queue;
    std::vector<std::pair<int, std::vector<int>>> attribute_vectors;
    queue.emplace(node, std::vector<int>{1});

    while (!queue.empty()) {
        std::pair<AOTree *, std::vector<int>>& pair = queue.front();
        AOTree* current = pair.first;
        std::vector<int> vec = pair.second;
        queue.pop();
        if (isType<AOAnd>(*current)) {
            auto *nodeAnd = (AOAnd*) current;
            std::vector<int> vec1 = vec;
            vec1.resize(counter, 0);
            vec1.push_back(1);
            queue.emplace(nodeAnd->getN1(), vec1);
            std::vector<int> vec2(counter, 0);
            vec2.push_back(-1);
            queue.emplace(nodeAnd->getN2(), vec2);
            ++counter;
        } else if (isType<AOOr>(*current)) {
            auto *nodeOr = (AOOr*) current;
            queue.emplace(nodeOr->getN1(), std::vector(vec));
            queue.emplace(nodeOr->getN2(), std::vector(vec));
        } else {
            auto *nodeAttribute = (AOAttribute*) current;
            attribute_vectors.emplace_back(nodeAttribute->getAttribute(), std::vector(vec));
        }
    }
    int matrix_size = attribute_vectors.size();
    std::vector<std::vector<int>> matrix(matrix_size);
    std::vector<int> row_to_attr(matrix_size);
    for (int i = 0; i < matrix_size; ++i) {
        std::pair<int, std::vector<int>>& pair = attribute_vectors[i];
        int attr = pair.first;
        std::vector<int>& vec = pair.second;
        vec.resize(counter, 0);
        matrix[i] = vec;
        row_to_attr[i] = attr;
    }
    return new LSSS(matrix_size, counter, matrix, row_to_attr);
}

std::optional<LSSS *> LSSS::from_AOTree_decrypt(AOTree *node, const std::vector<int> &attributes) {
    LSSS *lsss = from_AOTree(node);
    std::vector<std::vector<int>> matrix;
    std::vector<int> row_to_attr;
    for (int i = 0; i < lsss->rows; ++i) {
        int attr = lsss->row_to_attr[i];
        if (std::find(attributes.cbegin(), attributes.cend(), attr) != attributes.cend()) {
            matrix.push_back(lsss->matrix[i]);
            row_to_attr.push_back(attr);
        }
    }
    int matrix_size = matrix.size();
    int cols = lsss->cols;
    delete lsss;
    if (matrix_size == 0) {
        return std::nullopt;
    }
    return new LSSS(matrix_size, cols, matrix, row_to_attr);
}

LSSS::LSSS(int rows, int cols, std::vector<std::vector<int>> matrix, std::vector<int> row_to_attr) {
    this->rows = rows;
    this->cols = cols;
    this->matrix = std::move(matrix);
    this->row_to_attr = std::move(row_to_attr);
}

int LSSS::get_rows() const {
    return rows;
}

int LSSS::get_cols() const {
    return cols;
}

std::vector<int> LSSS::get_row(int i) {
    return matrix[i];
}

int LSSS::get_attr_from_row(int i) {
    return row_to_attr[i];
}

void LSSS::print() {
    std::cout << "--------------------------" << std::endl;
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            std::cout << matrix[i][j] << "\t";
        }
        std::cout << std::endl;
    }
    std::cout << "--------------------------" << std::endl;
}
