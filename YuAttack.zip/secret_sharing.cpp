#include "secret_sharing.h"

// Not a really efficient solution
std::map<int, element_t *> solve_lsss(pairing_t pairing, LSSS *lsss) {
    int curr_row = 0;
    int curr_col = 0;
    int pivot_col = 0;
    int colsmm = lsss->get_rows();
    size_t cols = colsmm + 1;
    size_t rows = lsss->get_cols();
    element_t *matrix[rows][cols];
    std::vector<int> attrs(colsmm);
    for (int i = 0; i < colsmm; ++i) {
        for (int j = 0; j < rows; ++j) {
            std::vector<int> row = lsss->get_row(i);
            attrs[i] = lsss->get_attr_from_row(i);
            matrix[j][i] = static_cast<element_t *>(pbc_malloc(sizeof(element_t)));
            element_init_Zr(*matrix[j][i], pairing);
            element_set_si(*matrix[j][i], row[j]);
        }
    }
    for (int i = 0; i < rows; ++i) {
        matrix[i][colsmm] = static_cast<element_t *>(pbc_malloc(sizeof(element_t)));
        element_init_Zr(*matrix[i][colsmm], pairing);
        if (i == 0) {
            element_set1(*matrix[i][colsmm]);
        } else {
            element_set0(*matrix[i][colsmm]);
        }
    }

    element_t temp, temp2;
    element_init_Zr(temp, pairing);
    element_init_Zr(temp2, pairing);
    while (true) {
        if (curr_col == cols || curr_row == rows) {
            break;
        }
        int row = -1;
        for (int i = curr_row; i < rows; ++i) {
            if (!element_is0(*matrix[i][curr_col])) {
                row = i;
                break;
            }
        }
        if (row != -1) {
            for (int i = 0; i < cols; ++i) {
                std::swap(matrix[curr_row][i], matrix[row][i]);
            }
            if (!element_is1(*matrix[curr_row][curr_col])) {
                for (int i = curr_col + 1; i < cols; ++i) {
                    element_div(*matrix[curr_row][i], *matrix[curr_row][i], *matrix[curr_row][curr_col]);
                }
                element_set1(*matrix[curr_row][curr_col]);
            }
            for (int i = curr_row + 1; i < rows; ++i) {
                if (!element_is0(*matrix[i][curr_col])) {
                    element_set(temp, *matrix[i][curr_col]);
                    for (int j = curr_col; j < cols; ++j) {
                        element_mul(temp2, temp, *matrix[curr_row][j]);
                        element_sub(*matrix[i][j], *matrix[i][j], temp2);
                    }
                }
            }
            for (int i = 0; i < curr_row; ++i) {
                if (!element_is0(*matrix[i][curr_col])) {
                    element_set(temp, *matrix[i][curr_col]);
                    for (int j = curr_col; j < cols; ++j) {
                        element_mul(temp2, temp, *matrix[curr_row][j]);
                        element_sub(*matrix[i][j], *matrix[i][j], temp2);
                    }
                }
            }
            pivot_col = curr_col;
            ++curr_row;
        }
        ++curr_col;
    }
    element_clear(temp);
    element_clear(temp2);
    if (pivot_col == colsmm) {
        pbc_die("Decryption not possible");
    }

    std::map<int, element_t *> result;
    std::vector<element_t *> solution;
    solution.reserve(colsmm);
    curr_col = 0;
    for (int i = 0; i < rows; ++i) {
        while (element_is0(*matrix[i][curr_col])) {
            ++curr_col;
            auto zero = static_cast<element_t *>(pbc_malloc(sizeof(element_t)));
            element_init_Zr(*zero, pairing);
            solution.push_back(zero);
            if (curr_col == cols) {
                goto outer;
            }
        }
        if (element_is1(*matrix[i][curr_col])) {
            ++curr_col;
            auto elem = static_cast<element_t *>(pbc_malloc(sizeof(element_t)));
            element_init_Zr(*elem, pairing);
            element_set(*elem, *matrix[i][cols - 1]);
            solution.push_back(elem);
        } else {
            pbc_die("Error");
        }
        if (curr_col == cols) {
            break;
        }
    }
    outer:
    while (solution.size() < colsmm)  {
        auto zero = static_cast<element_t *>(pbc_malloc(sizeof(element_t)));
        element_init_Zr(*zero, pairing);
        solution.push_back(zero);
    }
    while (solution.size() > colsmm)  {
        element_clear(*solution.back());
        pbc_free(solution.back());
        solution.pop_back();
    }
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            element_clear(*matrix[i][j]);
            pbc_free(matrix[i][j]);
        }
    }
    for (int i = 0; i < colsmm; ++i) {
        result[attrs[i]] = solution[i];
    }
    return result;
}