# Attack Example for Yu et al. - Decentralized, Revocable and Verifiable Attribute‑Based Encryption in Hybrid Cloud System - 2019

## Parameters

### Authorities
2 Authorities

Authority 1 attributes: {1, 2}

Authority 2 attributes: {3}

### Users
2 Users

Recipient attributes: {2, 3}

Attacker attributes: {}


### Ciphertext Policy
1 OR (2 AND 3)

## Process
- CA setup
- AA setup
- User secret key generation for recipient
- User secret key generation for attacker
- A randomly chosen message is encrypted with the ciphertext policy
- The recipient decrypts the message in the regular way
- The attacker decrypts the message without needing the attributes